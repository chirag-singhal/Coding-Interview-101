#include "dynalloc.h"

extern LinkedList createList(int n);

extern LinkedList createCycle(LinkedList ls);

extern int testCyclic(LinkedList ls);

extern LinkedList makeCyclic(LinkedList ls, int ifCyclic);
