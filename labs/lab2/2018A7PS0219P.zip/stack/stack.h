#include "linkedlist.h"

extern void push(struct linkedList* head, int x);

extern NODE* pop(struct linkedList* head);